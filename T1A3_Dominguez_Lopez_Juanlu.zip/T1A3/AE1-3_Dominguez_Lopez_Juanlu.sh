#!/bin/bash

# Script para gestión de usuarios y copias de seguridad
USUARIOS_FILE="usuarios.csv"
LOG_FILE="log.log"

# Verificación de existencia del archivo usuarios.csv y log.log
if [ ! -f "$USUARIOS_FILE" ]; then
    touch "$USUARIOS_FILE"
fi
if [ ! -f "$LOG_FILE" ]; then
    touch "$LOG_FILE"
fi

# Función para generar el nombre de usuario
generauser() {
    local nombre_usuario=$(echo "$1" | cut -c1 | tr '[:upper:]' '[:lower:]')
    local apellido1=$(echo "$2" | cut -c1-3 | tr '[:upper:]' '[:lower:]')
    local apellido2=$(echo "$3" | cut -c1-3 | tr '[:upper:]' '[:lower:]')
    local dni=$(echo "$4" | grep -oE '[0-9]{8}[A-Za-z]' | tail -c 4)
    echo "${nombre_usuario}${apellido1}${apellido2}${dni:0:3}"
}

# Función para mostrar el menú
menu() {
    echo "Seleccione una opción:"
    echo "1.- EJECUTAR COPIA DE SEGURIDAD"
    echo "2.- DAR DE ALTA USUARIO"
    echo "3.- DAR DE BAJA AL USUARIO"
    echo "4.- MOSTRAR USUARIOS"
    echo "5.- MOSTRAR LOG DEL SISTEMA"
    echo "6.- SALIR"
}

# Función de copia de seguridad
copia() {
    local backup_name="copia_usuarios_$(date +'%d%m%Y_%H-%M-%S').zip"
    zip "$backup_name" "$USUARIOS_FILE" > /dev/null 2>&1
    # Limita a las dos copias de seguridad más recientes
    local backups=( $(ls -t copia_usuarios_*.zip 2>/dev/null) )
    if [ ${#backups[@]} -gt 2 ]; then
        rm "${backups[2]}"
    fi
    echo "Copia de seguridad realizada: $backup_name" | tee -a "$LOG_FILE"
}

# Función para dar de alta a un usuario
alta() {
    # Validar el nombre
    while true; do
        read -p "Nombre: " nombre
        if [[ "$nombre" =~ ^[[:alpha:][:space:]]+$ ]]; then
            break
        else
            echo "El nombre no debe contener números. Inténtalo de nuevo."
        fi
    done
    
    # Validar el primer apellido
    while true; do
        read -p "Apellido 1: " apellido1
        if [[ "$apellido1" =~ ^[[:alpha:][:space:]]+$ ]]; then
            break
        else
            echo "El primer apellido no debe contener números. Inténtalo de nuevo."
        fi
    done

    # Validar el segundo apellido
    while true; do
        read -p "Apellido 2: " apellido2
        if [[ "$apellido2" =~ ^[[:alpha:][:space:]]+$ ]]; then
            break
        else
            echo "El segundo apellido no debe contener números. Inténtalo de nuevo."
        fi
    done

    # Validar el DNI
    while true; do
        read -p "DNI (8 números y 1 letra): " dni
        if [[ "$dni" =~ ^[0-9]{8}[A-Za-z]$ ]]; then
            break
        else
            echo "El DNI debe contener 8 números seguidos de 1 letra. Inténtalo de nuevo."
        fi
    done
    
    local nombre_usuario=$(generauser "$nombre" "$apellido1" "$apellido2" "$dni")
    
    if grep -q "^.*:.*:.*:.*:$nombre_usuario$" "$USUARIOS_FILE"; then
        echo "El usuario ya existe."
    else
        echo "$nombre:$apellido1:$apellido2:$dni:$nombre_usuario" >> "$USUARIOS_FILE"
        echo "INSERTADO $nombre:$apellido1:$apellido2:$dni:$nombre_usuario el $(date +'%d/%m/%Y a las %H:%M')" >> "$LOG_FILE"
        echo "Usuario añadido: $nombre_usuario"
    fi
}

# Función para dar de baja a un usuario
baja() {
    read -p "Nombre de usuario a eliminar: " nombre_usuario

    # Verificar si el usuario existe en el archivo
    if grep -q ":$nombre_usuario$" "$USUARIOS_FILE"; then
        # Usamos sed para eliminar la línea exacta que contiene al usuario
        sed -i.bak "/:$nombre_usuario$/d" "$USUARIOS_FILE"
        echo "BORRADO $nombre_usuario el $(date +'%d/%m/%Y a las %H:%M')" >> "$LOG_FILE"
        echo "Usuario eliminado: $nombre_usuario"
    else
        echo "Usuario no encontrado."
    fi
}



# Función para mostrar usuarios
mostrar_usuarios() {
    sort -t':' -k5 "$USUARIOS_FILE" | awk -F':' '{print $5 " - " $1 " " $2 " " $3 " (" $4 ")"}'
}

# Función para mostrar el log
mostrar_log() {
    cat "$LOG_FILE"
}

# Función de login
login() {
    local intentos=3
    local usuario_valido=0
    while [ $intentos -gt 0 ]; do
        read -sp "Introduce tu nombre de usuario: " username
        echo
        if [ "$username" == "admin" ]; then
            usuario_valido=1
            break
        elif grep -q ":$username$" "$USUARIOS_FILE"; then
            usuario_valido=1
            break
        else
            ((intentos--))
            echo "Usuario no válido. Intentos restantes: $intentos"
        fi
    done

    if [ $usuario_valido -eq 0 ]; then
        echo "No se ha podido iniciar sesión."
        exit 1
    fi
}

# Llamada a la función de login antes de mostrar el menú
login

# Ejecución del menú
while true; do
    menu
    read -p "Seleccione una opción: " opcion
    case $opcion in
        1) copia ;;
        2) alta ;;
        3) baja ;;
        4) mostrar_usuarios ;;
        5) mostrar_log ;;
        6) 
            break ;;
        *) echo "Opción no válida. Intente de nuevo." ;;
    esac
done