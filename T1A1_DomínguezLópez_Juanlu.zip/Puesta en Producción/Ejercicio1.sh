#!/bin/bash
# Muestra el nombre del script
echo "El nombre del script es: $0"
