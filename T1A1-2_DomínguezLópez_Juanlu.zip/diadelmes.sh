#!/bin/bash
# Obtiene el mes y el año actuales
mes=$(date +"%B")
anio=$(date +"%Y")
mes_num=$(date +"%m")

# Determina el número de días en el mes actual
if [[ "$mes_num" == "04" || "$mes_num" == "06" || "$mes_num" == "09" || "$mes_num" == "11" ]]; then
    dias=30
elif [[ "$mes_num" == "02" ]]; then
    # Verifica si el año es bisiesto para febrero
    if (( (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0) )); then
        dias=29
    else
        dias=28
    fi
else
    dias=31
fi

# Muestra la cantidad de días del mes actual
echo "Estamos en $mes, un mes con $dias días"
