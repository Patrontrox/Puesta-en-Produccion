#!/bin/bash
# Obtiene el nombre del mes actual y el número de días
mes=$(date +"%B")
dias=$(cal | awk 'NF {DAYS = $NF}; END {print DAYS}')

# Muestra la cantidad de días del mes actual
echo "Estamos en $mes, un mes con $dias días"
