#!/bin/bash
# Almacena el directorio recibido como parámetro
dir=$1

# Genera el nombre del archivo tar con la fecha actual
fecha=$(date +"%d%m%Y")
archivo="copia_scripts_$fecha.tar"

# Verifica si el directorio existe
if [ -d "$dir" ]; then
    # Encuentra archivos con extensión .sh y los añade al archivo tar
    find "$dir" -type f -name "*.sh" -exec tar -rvf "$archivo" {} +
    echo "Scripts empaquetados en $archivo"
else
    echo "El directorio no existe"
fi
