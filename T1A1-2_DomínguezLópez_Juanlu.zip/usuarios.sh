#!/bin/bash
# Bucle para consultar información de varios usuarios
while true; do
    # Solicita el nombre de usuario
    echo "Introduce el nombre de usuario:"
    read usuario

    # Verifica si el usuario existe en el sistema
    if id "$usuario" &>/dev/null; then
        # Muestra información del usuario
        echo "Usuario: $usuario"
        echo "UID: $(id -u $usuario)"
        echo "GID: $(id -g $usuario)"
        echo "Directorio de trabajo: $(eval echo ~$usuario)"
    else
        echo "El usuario no existe"
    fi

    # Pregunta si desea consultar otro usuario
    echo "¿Quieres buscar otro usuario? (s/n)"
    read respuesta
    if [[ "$respuesta" != "s" ]]; then
        break
    fi
done
