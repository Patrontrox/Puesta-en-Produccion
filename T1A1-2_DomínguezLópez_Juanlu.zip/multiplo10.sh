#!/bin/bash
# Solicita un número al usuario
echo "Introduce un número:"
read numero

# Verifica si el número es múltiplo de 10 usando el operador de módulo (%)
if (( numero % 10 == 0 )); then
    echo "$numero es múltiplo de 10"
else
    echo "$numero no es múltiplo de 10"
fi
