#!/bin/bash
# Solicita la edad del usuario
echo "Introduce tu edad:"
read edad

# Calcula el año actual y el año de nacimiento del usuario
anio_actual=$(date +"%Y")
anio_nacimiento=$((anio_actual - edad))

# Calcula la década a partir del año de nacimiento
decada=$(( (anio_nacimiento / 10) * 10 ))

# Muestra el resultado en el formato especificado
echo "Si naciste en $anio_nacimiento, naciste en la década de $decada"
