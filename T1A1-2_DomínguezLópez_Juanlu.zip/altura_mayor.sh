#!/bin/bash
# Solicita la altura de tres personas en centímetros
echo "Introduce la altura en cm de la primera persona:"
read altura1
echo "Introduce la altura en cm de la segunda persona:"
read altura2
echo "Introduce la altura en cm de la tercera persona:"
read altura3

# Encuentra la altura máxima entre las tres ingresadas
max_altura=$(echo "$altura1 $altura2 $altura3" | tr ' ' '\n' | sort -nr | head -n1)

# Convierte la altura máxima de cm a metros y muestra el resultado
echo "La altura mayor es $(echo "scale=2; $max_altura / 100" | bc) metros"
