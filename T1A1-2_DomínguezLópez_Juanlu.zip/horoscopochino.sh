#!/bin/bash
# Solicita el año de nacimiento del usuario
echo "Introduce tu año de nacimiento:"
read anio

# Define los animales del horóscopo chino
animales=("La rata" "El buey" "El tigre" "El conejo" "El dragón" "La serpiente" "El caballo" "La cabra" "El mono" "El gallo" "El perro" "El cerdo")

# Calcula el animal correspondiente usando el módulo 12
indice=$((anio % 12))

# Muestra el animal del horóscopo chino correspondiente
echo "Tu animal del horóscopo chino es: ${animales[indice]}"
