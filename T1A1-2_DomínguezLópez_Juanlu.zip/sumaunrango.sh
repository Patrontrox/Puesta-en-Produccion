#!/bin/bash
# Solicita dos números para definir el rango
echo "Introduce el primer número:"
read num1
echo "Introduce el segundo número:"
read num2

# Asegura que num1 sea menor o igual a num2
if (( num1 > num2 )); then
    temp=$num1
    num1=$num2
    num2=$temp
fi

# Calcula la suma de todos los números dentro del rango
suma=0
for (( i=num1; i<=num2; i++ )); do
    suma=$((suma + i))
done

# Muestra la suma total
echo "La suma del rango es $suma"
