#!/bin/bash
# Solicita el directorio al usuario
echo "Introduce el directorio que deseas verificar:"
read dir

# Verifica si el directorio existe
if [ -d "$dir" ]; then
    # Cuenta solo archivos regulares en el directorio sin incluir subdirectorios
    count=$(ls -l "$dir" | grep '^-' | wc -l)
    
    # Verifica si hay más de 10 archivos
    if (( count > 10 )); then
        echo "Hay más de 10 ficheros en $dir"
    else
        echo "Hay 10 o menos ficheros en $dir"
    fi
else
    echo "El directorio no existe"
fi
